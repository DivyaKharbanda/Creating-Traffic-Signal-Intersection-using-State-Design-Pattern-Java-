package myArrayList.util;

public interface FileDisplayInterface {
	void writeToFile(String testName);
}
