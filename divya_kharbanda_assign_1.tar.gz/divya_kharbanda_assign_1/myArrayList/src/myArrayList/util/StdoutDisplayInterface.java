package myArrayList.util;

public interface StdoutDisplayInterface 
{
	void writeToStdout(String testName);
}
